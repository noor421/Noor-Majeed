#include <iostream>
using namespace std;

int main() {
	int number, largest,n;
	cout<<"Enter the number of digits"<<endl;
	cin>>n;
	if(n<=0) {
		cout<<"The number is not valid please enter a valid number"<<endl;
}
cout<<"Enter"<<n<<"numbers"<<endl;
cin>>largest;
for(int i=1; i<n; i++){
	cin>>number;
	if(number>largest){
		largest=number;
	}
}
cout<<"The largest number is"<<largest<<endl;
return 0;
}