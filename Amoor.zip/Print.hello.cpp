#include <iostream>
using namespace std;
int main(){
	cout<<"Hello From C++!!!"<<endl;
	return 0;
}