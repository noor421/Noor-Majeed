#include <iostream>
using namespace std;
int main(){
	char i,j;
	for(int i='E';i>='A';i--){
		for(int j='E';j>='A';j--){
			cout<<char(j);
		}
	    	cout<<endl;
	}
	return 0;
}