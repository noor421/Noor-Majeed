 
#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Enter a number: ";
    cin >> N;

    for (int i = 1; i <= N; i++) {
        cout << i << " ";
    }

    cout << endl;
    return 0;
}