
#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Enter the number of elements: ";
    cin >> N;

    double sum = 0, number;
    for (int i = 1; i <= N; i++) {
        cout << "Enter number " << i << ": ";
        cin >> number;
        sum += number;
    }

    cout << "The average is: " << sum / N << endl;

    return 0;
}