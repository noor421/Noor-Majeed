#include <iostream>
using namespace std;
int main(){
	int a;
	cout<< "Enter the number:" << endl;
	cin>>a;
	if(a%2==0){
		cout<< " The given number is EVEN"<<endl;
	}else{
		cout<< "The given number iS ODD"<<endl;
	}
	return0;
}