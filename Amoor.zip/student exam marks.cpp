#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int s1,s2,s3;
    float avg;
    cout<<"Enter marks obtained in 3 subjects\n";
    cin>>s1>>s2>>s3;
    avg=(s1+s2+s3)/3.0;
    if(s1>40 && s2>40)
    {
        cout<<"Pass";
    }
    else if(s2>40 && s3>40)
    {
        cout<<"Pass";
    }
    else if(s3>40 && s1>40)
    {
        cout<<"Pass";
    }
    else if(avg>40)
    {
        cout<<"Pass";
    }
    else
    {
        cout<<"Fail";
    }
    return 0;
}