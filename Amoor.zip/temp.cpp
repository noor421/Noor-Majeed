#include <iostream>
using namespace std;
int main(){
	int celsius, fahrenheit;
	cout<<" Enter the number in Celsius"<<endl;
	cin>>celsius;
	fahrenheit =(celsius * 9/5) + 32;
	cout<<" Temperature in Fahrenheit is:"<< fahrenheit<<endl;
	return 0;
}