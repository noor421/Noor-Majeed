
#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Enter a number: ";
    cin >> N;
    
    int a = 0, b = 1, next;
    for (int i = 1; i <= N; i++) {
        if (i == 1) {
            cout << a << " ";
            continue;
        }
        if (i == 2) {
            cout << b << " ";
            continue;
        }
        next = a + b;
        a = b;
        b = next;
        cout << next << " ";
    }
    return 0;
}


