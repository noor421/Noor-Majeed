#include <iostream>
using namespace std;
int main(){
	int a,b,c, max;
	cout<< " Enter the three numbers"<<endl;
	cin>>a>>b>>c;
	if(a>b &&a>c){
		cout<<"The largest number:"<<a<<endl;
	}
	else if(b>c &&b>a){
		cout<<" The largest number :"<<b<<endl;
	}
	else if(c>a &&c>b){
		cout<<" The largest number :"<<c<<endl;
	}
	return 0;
}