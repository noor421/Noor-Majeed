
#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    cout << "Multiples of " << num << " up to 100 are: ";
    for (int i = num; i <= 100; i += num) {
        cout << i << " ";
    }
    cout << endl;

    return 0;
}