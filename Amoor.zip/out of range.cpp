#include <iostream>

using namespace std;

int main()
{
    string test = "500";
    cout<<"300 : "<<test[100];
    return 0;
}