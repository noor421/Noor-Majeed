
#include <iostream>
#include <sstream>
using namespace std;

int main() {
    string sentence;
    cout << "Enter a sentence: ";
    getline(cin, sentence);

    stringstream ss(sentence);
    string word;
    int wordCount = 0;

    while (ss >> word) {
        wordCount++;
    }

    cout << "The sentence has " << wordCount << " words." << endl;

    return 0;
}