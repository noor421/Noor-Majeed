
#include <iostream>
using namespace std;

int main() {
    int base, exponent;
    long long result = 1;

    cout << "Enter base and exponent: ";
    cin >> base >> exponent;

    for (int i = 1; i <= exponent; i++) {
        result *= base;
    }

    cout << base << " raised to the power " << exponent << " is " << result << endl;

    return 0;
}
