#include <iostream>
using namespace std;
int main(){
	int i;
	for(int i=1;i<=10;i++){
		cout<<" The value is:"<<i<<endl;
	}
	return 0;
}