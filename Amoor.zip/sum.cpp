#include <iostream>
using namespace std;
int main(){
	int a,b,sum;
	cout<<" Write a number"<<endl;
	cin>>a;
	cout<<"Write another number"<<endl;
	cin>>b;
	cout<<"The sum of number is:"<<a+b<<endl;
	return 0;
}