#include<iostream>
using namespace std;

int main(){
int n;
long factorial =1.0;

    cout << "enter a positive integer: ";
    cin >> n;
    cout << " factorial of "<< n <<" = "<< factorial;
    return 0;
}