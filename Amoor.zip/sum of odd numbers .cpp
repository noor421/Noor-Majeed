
#include <iostream>
using namespace std;

int main() {
    int N, sum = 0;
    cout << "Enter a number: ";
    cin >> N;

    for (int i = 1; i <= N * 2; i += 2) {
        sum += i;
    }

    cout << "Sum of first " << N << " odd numbers is: " << sum << endl;

    return 0;
}
